%% FaunaData Post-Processing -
%
%       Created and written by Dave Haas, 18 June 2021
%
%       Based on FaunaDataDataWorkup.m, which was created by Dave Haas
%       between 17 June 2020 - 18 June 2021. This unpacks FaunaTag data
%       from its CSV format, puts it into row-major data for Matlab,
%       partitions the data into RAW structures (default sampling rates)
%       and PRH structures (25 Hz decimated data).
%
%       Dependency: csvproc from dtagtools by Mark Johnson

clc;
clear;

%%  Load global TAG_PATHS and verify they're where they should be...

global TAG_PATHS;

if (exist(TAG_PATHS.RAW,'dir'))
    fprintf('RAW data folder specified in TAG_PATHS is present.\n');
else
    fprintf('RAW data folder specified in TAG_PATHS is not present.\n');
    fprintf('Fix missing RAW data folder and retry.\n');
    return;
end

if (exist(TAG_PATHS.PRH,'dir'))
    fprintf('PRH data folder specified in TAG_PATHS is present.\n');
else
    fprintf('PRH data folder specified in TAG_PATHS is not present.\n');
    fprintf('Fix missing PRH data folder and retry.\n');
    return;
end

if (exist(TAG_PATHS.METADATA,'dir'))
    fprintf('Meta data folder specified in TAG_PATHS is present.\n');
else
    fprintf('Meta data folder specified in TAG_PATHS is not present.\n');
    fprintf('Fix missing meta data folder and retry.\n');
    return;
end

%% define some standard FaunaLabs plotting colors

% named colors
blue = [0 0.4470 0.7410];           % '#0072BD';
red = [0.8500 0.3250 0.0980];       % '#D95319'	
goldenrod = [0.9290 0.6940 0.1250];	% '#EDB120'	
purple = [0.4940 0.1840 0.5560];    % '#7E2F8E'	
green = [0.4660 0.6740 0.1880];     % '#77AC30'	
cyan = [0.3010 0.7450 0.9330];      % '#4DBEEE'	
maroon = [0.6350 0.0780 0.1840];    % '#A2142F'
black = [0 0 0];                    % '#000000

%%  begin FaunaTag post-processing by choosing a tag, date, and trial set

fprintf('\n\n---=== Starting FaunaData Post-processing! ===---\n\n');

useGoogle = false;

if (useGoogle)
    pathName = '/Volumes/GoogleDrive/Shared drives/FaunaData';
else
    pathName = '/Users/dave/Documents/FaunaData';
end

% specify subpath depending on whether its my data or animal data

animalData = true;                 %       <-- BE SURE TO SPECIFY THIS

if (animalData)
    subPath = 'DQO';
else
    subPath = 'DH';
end

tagID = 'FaunaTag111';              %       <-- BE SURE TO SPECIFY THIS

dateID = '20210522';                %       <-- BE SURE TO SPECIFY THIS

if(animalData)

    % FaunaTag 110 - all NIR LEDs failed after leaving NC :(
    
    % ----- ----- ----- ----- 3 May 2021 ----- ----- ----- ----- 
    %fileName = 'ft110_20210503_091613-10.txt';     % Kolohe III R
    %totd = 'ab';
    %fileName = 'ft110_20210503_121325-10.txt';     % Kolohe II 
    %totd = 'd';
    %fileName = 'ft110_20210503_143350-10.txt';     % Hua I
    %totd = 'g';
    %fileName = 'ft110_20210503_153936-10.txt';     % Liho II
    %totd = 'i';

    % FaunaTag 111 
    
    % ----- ----- ----- ----- 3 May 2021 ----- ----- ----- ----- 
    %fileName = 'ft111_20210503_113626-10.txt';     % Hoku III R
    %totd = 'c';
    %fileName = 'ft111_20210503_142825-10.txt';    % Hua II
    %totd = 'f';
    %fileName = 'ft111_20210503_153233-10.txt';     % Liho II
    %totd = 'h';
    
    % ----- ----- ----- ----- 7 May 2021 ----- ----- ----- ----- 
    %fileName = 'ft111_20210507_140742-10.txt';     % Kolohe I II & III L
    %totd = 'abc';
    %fileName = 'ft111_20210507_145342-10.txt';     % Hoku I & II
    %totd = 'de';
    
    % ----- ----- ----- ----- 8 May 2021 ----- ----- ----- ----- 
    %fileName = 'ft111_20210508_091836-10.txt';     % Hua I & II
    %totd = 'ab';
    %fileName = 'ft111_20210508_114531-10.txt';     % Hoku I II III L & IV  
    %totd = 'cdef';
    %fileName = 'ft111_20210508_143600-10.txt';     % Kolohe I & II
    %totd = 'gh';
    %fileName = 'ft111_20210508_155047-10.txt';     % Liho I
    %totd = 'i';
    
    % ----- ----- ----- ----- 10 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210510_134417-10.txt';     % Kolohe III L
    %totd = 'a';
    
    %fileName = 'ft111_20210510_141230-10.txt';     % Hua I II III L
    %totd = 'bcd';
    
    %fileName = 'ft111_20210510_151032-10.txt';     % Noa I & II
    %totd = 'ef';
    
    %fileName = 'ft111_20210510_161759-10.txt';     % Liho II
    %totd = 'g';
    
    % ----- ----- ----- ----- 11 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210511_102145-10.txt';     % Noa III L, no recover
    %totd = 'a';
    
    %fileName = 'ft111_20210511_113352-10.txt';     % Liho III R
    %totd = 'b';
    
    %fileName = 'ft111_20210511_132316-10.txt';     % DH & ambient laggon 1
    %totd = 'X';
    
    %fileName = 'ft111_20210511_141052-10.txt';     % Lono I
    %totd = 'c';
    
    %fileName = 'ft111_20210511_160612-10.txt';     % Lono II & III L
    %totd = 'de';
    
    
    % ----- ----- ----- -----             ----- ----- ----- ----- 
    % ----- ----- ----- vvvvv Foil Trials vvvvv ----- ----- ----- 
    % ----- ----- ----- -----             ----- ----- ----- ----- 
    
    
    % ----- ----- ----- ----- 13 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210513_110326-10.txt';     % Hoku, foil I & II
    %totd = 'ab';
    
    %fileName = 'ft111_20210513_114729-10.txt';     % Kolohe, foil I & II
    %totd = 'cd';
    
    %fileName = 'ft111_20210513_140811-10.txt';     % Liho, foil I II III R
    %totd = 'efg';
    
    %fileName = 'ft111_20210513_151511-10.txt';     % Kolohe w/ foil III R
    %totd = 'h';
    
    % ----- ----- ----- ----- 14 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210514_085503-10.txt';     % Liho w/ foil IV
    %totd = 'a';
    
    %fileName = 'ft111_20210514_100519-10.txt';     % Kolohe w/ foil IV
    %totd = 'b';

    %fileName = 'ft111_20210514_121738-10.txt';     % Hoku w/ foil III
    %totd = 'c';

    % ----- ----- ----- ----- 21 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210521_091400-10.txt';     % Hua w/ foil I & III
    %totd = 'ab';
    
    %fileName = 'ft111_20210521_094909-10.txt';     % Lono w/ foil I & III
    %totd = 'cd';
    
    %fileName = 'ft111_20210521_110615-10.txt';     % Hua w/ foil IV
    %totd = 'e';
    
    % ----- ----- ----- ----- 22 May 2021 ----- ----- ----- ----- 
    
    %fileName = 'ft111_20210522_090501-10.txt';     % Noa w/ foil I III & IV
    %totd = 'abc';
    
    fileName = 'ft111_20210522_112033-10.txt';     % Lono w/ foil IV
    totd = 'd';
        
   
    % ----- ----- ----- ----- 3 May 2021 ----- ----- ----- ----- 
    
    % FaunaTag 112 - all NIR LEDs failed or there's a problem with the PD
    
    %fileName = 'ft112_20210503_142040-10.txt';     % Hua I
    %totd = 'e';
    
    % ^^^^^^^^^^^^^^^^ DOLPHIN DATA ^^^^^^^^^^^^^^^^^^^^
    
else        
    
    % vvvvvvvvvvvvvvvv HUMAN (DH) DATA vvvvvvvvvvvvvvvvv
    
    %fileName = 'ft106_20210506_110258-10.txt';
    %fileName = 'ft106_20210506_140815-10.txt';
    %fileName = 'ft110_20210505_170048-10.txt'; 
    %fileName = 'ft110_20210506_144129-10.txt';
    %fileName = 'ft110_20210506_145450-10.txt';
    %fileName = 'ft110_20210506_150322-10.txt';
    %fileName = 'ft110_20210506_150856-10.txt';
    %fileName = 'ft110_20210506_153231-10.txt';
    %fileName = 'ft110_20210506_190040-10.txt';
    %fileName = 'ft110_20210507_062207-10.txt';
    %fileName = 'ft110_20210507_062957-10.txt';
    %fileName = 'ft110_20210507_070110-10.txt';
    %fileName = 'ft110_20210507_115233-10.txt';
    %fileName = 'ft110_20210512_164025-10.txt';
    %fileName = 'ft110_20210512_165227-10.txt';
    
    %fileName = 'ft111_20210505_165240-10.txt'; 
    %fileName = 'ft111_20210506_161055-10.txt';
    %fileName = 'ft111_20210506_161747-10.txt';
    %fileName = 'ft111_20210506_164114-10.txt';
    %fileName = 'ft111_20210506_171603-10.txt';
    %fileName = 'ft111_20210506_174142-10.txt';
    %fileName = 'ft111_20210506_181726-10.txt'; 
    %fileName = 'ft111_20210507_073000-10.txt';
    %fileName = 'ft111_20210507_101715-10.txt';
    %fileName = 'ft111_20210507_103456-10.txt';
    %fileName = 'ft111_20210512_162301-10.txt';
    %fileName = 'ft111_20210512_180612-10.txt';
    
    %fileName = 'ft112_20210507_071747-10.txt';
    %fileName = 'ft112_20210507_093534-10.txt';
    %fileName = 'ft112_20210507_122200-10.txt';
    
end


% now, build a complete targetFile for open...
targetFile = sprintf('%s/%s/%s/%s/%s', pathName, subPath, tagID, dateID, fileName);

fileExists = isfile(targetFile);

if (fileExists)
    fprintf('Target file exists... reading data...\n');
    youShallNotPass = false;
    % load targetFile into S
    S = csvproc(targetFile, []);    
else
    fprintf('File you specified does not seem to exist...\n\n');
    youShallNotPass = true;
    return;
end


%% parse fileName, make date, time, utcOffset, etc., generate prhFileName

fprintf('Parsing filename into date-time components...\n');

if (strncmp(fileName, 'ft110', 5))
    FaunaTagID = 110;
elseif (strncmp(fileName, 'ft111', 5))
    FaunaTagID = 111;
elseif (strncmp(fileName, 'ft112', 5))
    FaunaTagID = 112;
end


YYYY = str2double(extractBetween(fileName, 7, 10));
YY   = str2double(extractBetween(fileName, 9, 10));
MM   = str2double(extractBetween(fileName, 11,12));
DD   = str2double(extractBetween(fileName, 13,14));

hh   = str2double(extractBetween(fileName, 16,17));
mm   = str2double(extractBetween(fileName, 18,19));
ss   = str2double(extractBetween(fileName, 20,21));

utc  = str2double(extractBetween(fileName, 22,24));

J    = jday([YYYY MM DD]);

trialDate = [YYYY MM DD];

trialDateTimeLocal = datetime(YYYY, MM, DD, hh, mm, ss);
trialDateTimeUTC   = datetime(YYYY, MM, DD, hh + (utc * -1), mm, ss);

if (YYYY == 2021 & MM == 5)  
    
    % these are all DQO dolphins, so auto-fill this info...
    
    gs = 'tt';
    lat = 21.272037;            % decimal degrees at Dolphin Quest Oahu
    long = -157.773116;         % decimal degrees at Dolphin Quest Oahu
    decl = 9.48;                % units: degrees, on 13 May 2021
    magFieldStrength = 34797.5; % field strength, units: nanoTeslas (nT)
    
else
    
    % ... but enter this manually if not DQO trials ...
    
    validMetaData = false;
    
    while(validMetaData == false)
        
        fprintf('\n----- Enter tag meta data information manually... -----\n\n');
    
        genus = input('Animal genus (e.g.: Tursiops): ','s');
        species = input('Animal species (e.g.: truncatus): ','s');
        gsCode = input('Enter the genusSpecies code for tagID (e.g.: tt): ', 's');
        latitude = input('Enter tagOn latitude in decimal degrees (S is negative): ', 's');
        longitude = input('Enter tagOn longitude in decimal degrees (W is negative): ', 's');
        declAngle = input('Enter declination angle in degrees: ', 's');
        fieldStrength = input('Enter magnetic field strength in nT: ', 's');

        lat = str2double(latitude);
        long = str2double(longitude);
        decl = str2double(declAngle);
        magFieldStrength = str2double(fieldStrength);

        % verify the condition of user entries...

        if ( isempty(genus) || isempty(species) || isempty(gsCode) || ...
                (strlength(gsCode) ~= 2) || ...
                isnan(lat)|| isnan(long) || ... 
                isnan(decl) || isnan(magFieldStrength ) )
            validMetaData = false;
            fprintf('\nTag meta data entered is invalid... Try re-entering it...\n\n');
        else
            validMetaData = true;
            fprintf('Tag meta data seems valid... continuing!\n\n');
        end
        
    end
    
end

rawFileName = sprintf('%s%d_%d%sraw.mat',gs,YY,J,totd);
prhFileName = sprintf('%s%d_%d%sprh.mat',gs,YY,J,totd);
metadataFileName = sprintf('%s%d_%d%smeta.mat',gs,YY,J,totd);

tag = sprintf('%s%d_%d%s', gs,YY,J,totd);

fprintf('\nTag ID: %s\n', tag);
fprintf('RAW filename: %s\n', rawFileName);
fprintf('PRH filename: %s\n', prhFileName);
fprintf('METADATA filename: %s\n', metadataFileName);


%% check to see if there's a meta data file for this tag...

fprintf('Metadata file is specified as: %s\n', metadataFileName);
goodMetaData = lower(input('Is this correct? (y/n): ','s'));
switch(goodMetaData)
    
    case 'y'
        fprintf('Good. Continuing with metadata file load...\n');
        
    otherwise   % repeat until good metadata file name is specified...

        validMetaDataFileName = false;
        
        while(~validMetaDataFileName)
            
            fprintf('You said this is the wrong metadata file.\n');
            correctTrial = input('Enter the correct one: ','s');
            
            % validate correctMetaData structure
            gsCode = string(extractBetween(correctTrial, 1, 2));
            yyCode = str2double(extractBetween(correctTrial, 3, 4));
            usCode = string(extractBetween(correctTrial, 5, 5));
            doyCode = str2double(extractBetween(correctTrial, 6, 8));
            trialCode = string(extractBetween(correctTrial, 9, 9));

            if (  ( gsCode >= 'aa' & gsCode <= 'zz' ) & ...
                (yyCode >= 00 & yyCode <= 99) & ...
                (strcmp(usCode,'_')) ...
                & (doyCode >= 001 & doyCode <= 366) & ...
                (trialCode >= 'a' & trialCode <= 'z') )
                
            % correctMetaData seems valid-ish
                fprintf('New metadata file seems valid: %s\n', ...
                    correctTrial);
                fprintf('Correcting tag trial, META, RAW & PRH names...\n');
                
                validMetaDataFileName = true;
                tag = sprintf('%s', correctTrial);
                rawFileName = sprintf('%sraw.mat', correctTrial);
                prhFileName = sprintf('%sprh.mat', correctTrial);
                metadataFileName = sprintf('%smeta.mat', correctTrial);
                
                fprintf('\nTag ID: %s\n', tag);
                fprintf('RAW filename: %s\n', rawFileName);
                fprintf('PRH filename: %s\n', prhFileName);
                fprintf('METADATA filename: %s\n', metadataFileName);
                
            else
                fprintf('New metadata file seems INVALID: %s\n', correctTrial);
                fprintf('Check the name and try this again...\n');
                validMetaDataFileName = false;
            end
        end
end


fullMetadataFileName = sprintf('%s/%s', TAG_PATHS.METADATA, ...
    metadataFileName);
if ( exist(fullMetadataFileName, 'file') )
    fprintf('Metadata file located for this trial... loading it!\n');
    load(fullMetadataFileName);
    % confirm presence of TRIAL variable
    if ( exist('TRIAL','var') )
        fprintf('TRIAL variable is present and loaded...\n');
        disp(TRIAL);
        disp(TRIAL.SUBJECT);
        disp(TRIAL.CUES);
        fprintf('\n');
    else
        fprintf('TRIAL variable is not present. Investigate.\n');
        return;
    end
else
    fprintf('Metadata file not located for this trial...\n');    
    loadMetaDataStr = input('Do you want to specify one? (y/n) [y] ','s');
    if (isempty(loadMetaDataStr))
        loadMetaDataStr = 'y';
    end
    switch(loadMetaDataStr)
        case 'y'
            metaDataFileText = 'Specify a tag (e.g.: tt21_134a): ';
            metaDataFileStr = input(metaDataFileText,'s');
            if (~isempty(metaDataFileStr))
                metaDataFile = sprintf('%s/%smeta.mat', ...
                    TAG_PATHS.METADATA, metaDataFileStr);
                load(metaDataFile);
                if (exist('TRIAL','var'))
                    fprintf('--------------------------------------------------------\n');
                    disp(TRIAL);
                    fprintf('Loaded a valid TRIAL.\n');
                else
                end
            else
                fprintf('Skipping metadata. You will need to manage this later.\n');
            end
        otherwise
            fprintf('Skipping metadata. You will need to manage this later.\n');
    end
end

%% Load TRIAL into a timetable

lenTrialCuesTime = length(TRIAL.CUES.time);

TRIAL.CUES.duration(1:lenTrialCuesTime) = duration([ 0 0 0 ]);

if (lenTrialCuesTime == 1)
    
    if (isempty(TRIAL.CUES.type))
        TRIAL.CUES.type = {'test'};
    end

    if (isempty(TRIAL.CUES.comment))
        TRIAL.CUES.comment = {'test'};
    end
   
end

% make a replacement array of TRIAL.CUE.time(:) datetimes without timezone

cueDateTimes(1:lenTrialCuesTime) = datetime('now', 'InputFormat', ...
    'd-MMM-y HH:mm:ss','TimeZone','' );

for i = 1:lenTrialCuesTime
    cueDateTimes(i) = datetime(TRIAL.CUES.time(i), 'Format', ...
        'd-MMM-y HH:mm:ss Z', 'TimeZone', '');
end


CUE = timetable(cueDateTimes', TRIAL.CUES.duration', ...
    TRIAL.CUES.type', TRIAL.CUES.comment','VariableNames', ...
    {'duration','type','comment' } );     

CUE = addprop(CUE,{'tag','tagNumber','attachmentLocation','attachmentSide',...  % 4
    'dataFile','tagStartTimeLocal','tagStartTimeUTC','utcOffset', ...           % 4
    'loggedActivationTime','loggedTagOnTime','loggedTagOffTime', ...            % 3
    'loggedDeactivationTime','tagTimeLogTimeDifference','latitude', ...            % 3
    'longitude','declination','magFieldStrength','investigatorName', ...        % 4
    'participantNames','notes','SUBJECT' }, ...                                           % 2
    {'table','table','table','table', ...
    'table','table','table','table', ...
    'table','table','table', ...
    'table','table','table', ...
    'table','table','table','table', ...
    'table','table', 'table'} );
    
CUE.Properties.CustomProperties.tag = TRIAL.tag;
CUE.Properties.CustomProperties.tagNumber = TRIAL.tagNumber;
CUE.Properties.CustomProperties.attachmentLocation = TRIAL.attachmentLocation;
CUE.Properties.CustomProperties.attachmentSide = TRIAL.attachmentSide;
CUE.Properties.CustomProperties.dataFile = TRIAL.dataFile;
CUE.Properties.CustomProperties.tagStartTimeLocal = TRIAL.tagStartTimeLocal;
CUE.Properties.CustomProperties.tagStartTimeUTC = TRIAL.tagStartTimeUTC;
CUE.Properties.CustomProperties.utcOffset = TRIAL.utcOffset;
CUE.Properties.CustomProperties.loggedActivationTime = TRIAL.loggedActivationTime;
CUE.Properties.CustomProperties.loggedTagOnTime = TRIAL.loggedTagOnTime;
CUE.Properties.CustomProperties.loggedTagOffTime = TRIAL.loggedTagOffTime;
CUE.Properties.CustomProperties.loggedDeactivationTime = TRIAL.loggedDeactivationTime;
CUE.Properties.CustomProperties.tagTimeLogTimeDifference = TRIAL.tagTimelogTimeDifference;
CUE.Properties.CustomProperties.latitude = TRIAL.latitude;
CUE.Properties.CustomProperties.longitude = TRIAL.longitude;
CUE.Properties.CustomProperties.declination = TRIAL.declination;
CUE.Properties.CustomProperties.magFieldStrength = TRIAL.magFieldStrength;
CUE.Properties.CustomProperties.investigatorName = TRIAL.investigatorName;
CUE.Properties.CustomProperties.participantNames = TRIAL.participantNames;
CUE.Properties.CustomProperties.notes = TRIAL.notes;
CUE.Properties.CustomProperties.SUBJECT = TRIAL.SUBJECT;



%% parse S into usable data components

if (youShallNotPass)
    fprintf('The data file was missing. Find the right now and try again!\n');
    return;
end

fprintf('Parsing data into usable components...\n');

% optics (relative insensity)           @ 250 Hz
led2 = str2double(S(1,:));
led3 = str2double(S(2,:));
led1 = str2double(S(3,:));              % this should be ambient
led4 = str2double(S(4,:));

% transform data for reflectance measurements, i.e.: make negative then
% rebase around lower bound values for rough DC offset

rLed1 = (led1 * -1);
rLed2 = (led2 * -1);
rLed3 = (led3 * -1);
rLed4 = (led4 * -1);

rLed1Min = min(rLed1);
rLed2Min = min(rLed2);
rLed3Min = min(rLed3);
rLed4Min = min(rLed4);

rLed1 = rLed1 - rLed1Min;
rLed2 = rLed2 - rLed2Min;
rLed3 = rLed3 - rLed3Min;
rLed4 = rLed4 - rLed4Min;

% normalize these signals for later use
normLed1 = normalize(led1);
normLed2 = normalize(led2);
normLed3 = normalize(led3);
normLed4 = normalize(led4);

nrLed1 = normalize(rLed1);
nrLed2 = normalize(rLed2);
nrLed3 = normalize(rLed3);
nrLed4 = normalize(rLed4);

% bioOptics (optical intensity)         @ 250 Hz
num250HzSamples = length(led2);
numSecondsData = num250HzSamples / 250;

% accel (meters per second squared)     @ 100 Hz
ax = str2double(S(5,1:numSecondsData * 100));
ay = str2double(S(6,1:numSecondsData * 100));
az = str2double(S(7,1:numSecondsData * 100));

% use raw accel to create high-resolution ODBA and normalized ODBA
odba = sqrt(ax.^2 + ay.^2 + az.^2);
normOdba = normalize(sqrt(ax.^2 + ay.^2 + az.^2));

% gyro (degrees per second)             @ 100 Hz
gx = str2double(S(8,1:numSecondsData * 100));
gy = str2double(S(9,1:numSecondsData * 100));
gz = str2double(S(10,1:numSecondsData * 100));

% is there an ODBA-like version for gyroscope? there is now...
% call it Overall Dynamic Gyroscopic Signal
odav = sqrt(gx.^2 + gy.^2 + gz.^2);
normOdav = normalize(sqrt(gx.^2 + gy.^2 + gz.^2));

% prh (degree)                          @ 100 Hz
pitch   = str2double(S(11,1:numSecondsData * 100));
roll    = str2double(S(12,1:numSecondsData * 100));
heading = str2double(S(13,1:numSecondsData * 100));

% depth (meters)                        @ 100 Hz
depth = str2double(S(14,1:numSecondsData * 100));

% temp (degrees Celsius)                @ 100 Hz
temperature = str2double(S(15,1:numSecondsData * 100));

% mag (degree)                                  @ 20 Hz
mx = str2double(S(16,1:numSecondsData * 20));
my = str2double(S(17,1:numSecondsData * 20));
mz = str2double(S(18,1:numSecondsData * 20));

% timestamp                                     @ 2 Hz
sampletime = str2double(S(19,1:numSecondsData * 2));

% power measurements                            @ 2 Hz
voltage             = str2double(S(20,1:numSecondsData * 2));
current             = str2double(S(21,1:numSecondsData * 2));
power_mW            = str2double(S(22,1:numSecondsData * 2));
chargeState         = str2double(S(23,1:numSecondsData * 2));
remainingCapacity   = str2double(S(24,1:numSecondsData * 2));

%% Build sensor-specific times for the FaunaTag's raw data types

fprintf('Building frequency-appropriate time scales and sensor structures...\n');

opticsFs = 250;
movementFs = 100;
magFs = 20;
powerFs = 2;

numOpticsSamples = length(led1);
opticsSamplingIncrement = 1/opticsFs;
opticsTime_s = 0:opticsSamplingIncrement:(numOpticsSamples/opticsFs)-opticsSamplingIncrement;
opticsTime = trialDateTimeLocal + seconds(opticsTime_s);

numMovementSamples = length(ax);
moveSamplingIncrement = 1/movementFs;
moveTime_s = 0:moveSamplingIncrement:(numMovementSamples/movementFs)-moveSamplingIncrement;
moveTime = trialDateTimeLocal + seconds(moveTime_s);

numMagSamples = length(mx);
magSamplingIncrement = 1/magFs;
magTime_s = 0:magSamplingIncrement:(numMagSamples/magFs)-magSamplingIncrement;
magTime = trialDateTimeLocal + seconds(magTime_s);

numPowerSamples = length(voltage);
powerSamplingIncrement = 1/powerFs;
powerTime_s = 0:powerSamplingIncrement:(numPowerSamples/powerFs)-powerSamplingIncrement;
powerTime = trialDateTimeLocal + seconds(powerTime_s);

%% Create MATLAB time tables for each of these

fprintf('Constructing timetables of raw FaunaTag data...\n');

optics = timetable(opticsTime', opticsTime_s', led1', led2', led3', ...
    led4', 'VariableNames', {'time_s','led1','led2','led3','led4'} );

kinematics = timetable(moveTime', moveTime_s', ax', ay', az', ...
    gx', gy', gz', pitch', roll', heading', odba', odav', ...
    'VariableNames', {'time_s','ax','ay','az','gx','gy','gz','pitch', ...
    'roll', 'heading', 'odba', 'odav'} );

pressure = timetable(moveTime', moveTime_s', depth', temperature', ...
    'VariableNames', {'time_s','depth','temperature' } );

mag = timetable(magTime', magTime_s', mx', my', mz', 'VariableName', ...
    {'time_s','mx','my','mz'} );

power = timetable(powerTime', powerTime_s', voltage', current', ...
    power_mW', chargeState', remainingCapacity', 'VariableNames', ...
    {'time_s','voltage','current','power','chargeState', ...
    'remainingCapacity' } );

%% Create a TAG struct that contains universal meta data for the record

%  IS THIS EVEN RELEVANT NOW?!?!  ALL THIS DATA IS IN 'TRIAL' META DATA...

%  Note: this struct contains elements common to both RAW and PRH

TAG = struct;
TAG.id = FaunaTagID;
TAG.startTimeLocal = trialDateTimeLocal;
TAG.startTimeUTC = trialDateTimeUTC;
TAG.utcOffset = utc;
TAG.latitude = lat;
TAG.longitude = long;
TAG.latitudeUnits = 'decimal degrees';
TAG.longitudeUnits = 'decimal degrees';
TAG.declination = decl;
TAG.declinationUnits = 'degrees';
TAG.magneticFieldStrength = magFieldStrength;
TAG.magFieldStrengthUnits = 'nT';
TAG.originalFileName = fileName;


%% Ask about doing partitioning now for multi-trial tag deployments...

partitionAskStr = lower(input('Partition trial data (y/n) [n]: ','s'));
switch(partitionAskStr)
    case 'y'
        doPartitioning = true;
        useRaw = true;
    otherwise
        doPartitioning = false;
end

%% If doPartitioning is true, do this stuff next...

while (doPartitioning)

    % plot LED2 and LED3
    
    figPart = figure;
    
    plot(optics.Time, optics.led2, optics.Time, optics.led3);
    grid;
    
    % ask user to do two clicks for defining the start region
    startRegionDefined = false;
    
    % ask user to do two clicks to zoom in on the start region
    while(~startRegionDefined)
        
        fprintf('Click once to set the left-edge of the start region.\n');
        [xStartZoom1, ~, ~] = ginput(1);
        xAxis = gca;
        xStart1 = num2ruler(xStartZoom1, xAxis.XAxis);
        
        fprintf('Click once to set the right-edge of the start region.\n');
        [xStartZoom2, ~, ~] = ginput(1);
        xStart2 = num2ruler(xStartZoom2, xAxis.XAxis);

        startL = retime(optics, xStart1, 'nearest');
        startR = retime(optics, xStart2, 'nearest');
        
        startRange = timerange(startL.Time, startR.Time);
    
        figure(figPart);
        plot(optics.Time(startRange), optics.led2(startRange), ...
            optics.Time(startRange), optics.led3(startRange) );
        grid;
        
        % ask user if this is good enough to select an end or do more zooming
        startGoodTxt = 'Is this zoom level good enough? (y/n): ';
        startRegionGood = lower(input(startGoodTxt,'s'));        
        
        switch(startRegionGood)
            case 'y'
                startRegionDefined = true;
            otherwise
                startRegionDefined = false;
        end
        
    end
    
    % click once for trialStart and mvoe on once the user confirms
    trialStartConfirm = false;
    while (~trialStartConfirm)
        
        fprintf ('Click once for the trial start point.\n');
        [xStart,~,~] = ginput(1);
        xAxis = gca;
        partStart = num2ruler(xStart, xAxis.XAxis);
        
        opticsStart = retime(optics, partStart, 'nearest');
        kinematicsStart = retime(kinematics, partStart, 'nearest');
        pressureStart = retime(pressure, partStart, 'nearest');
        magStart = retime(mag, partStart, 'nearest');
        powerStart = retime(power, partStart, 'nearest');
        
        fprintf('oStart: %.1f | kStart: %.1f\n', opticsStart.time_s, ...
            kinematicsStart.time_s);
        
        trialStartConfirmTxt = 'Is this a good trialStart point (y/n)? ';
        trialStartConfirmStr = lower(input(trialStartConfirmTxt, 's'));
        switch(trialStartConfirmStr)
            case 'y'
                trialStartConfirm = true;
            otherwise
                trialStartConfirm = false;
        end
    end
    
    newPartRange = timerange(opticsStart.Time, optics.Time(end));
    
    % replot LED2 and LED3, starting from the now-defined start point
    figure(figPart);
    plot(optics.Time(newPartRange), optics.led2(newPartRange), ...
        optics.Time(newPartRange), optics.led3(newPartRange) );
    grid;
    
    % ask user to do two clicks to zoom in on the end region
    
    endRegionDefined = false;

    while(~endRegionDefined)
        
        fprintf('Click once to set the left-edge of end region selection.\n');
        [xEndZoom1, ~, ~] = ginput(1);
        
        fprintf('Click once to set the right-edge of end region selection.\n');
        [xEndZoom2, ~, ~] = ginput(1);
        
        xAxis = gca;
        xEnd1 = num2ruler(xEndZoom1, xAxis.XAxis);
        xEnd2 = num2ruler(xEndZoom2, xAxis.XAxis);
        
        newEndRange = timerange(xEnd1, xEnd2);
        
        figure(figPart);
        plot(optics.Time(newEndRange), optics.led2(newEndRange), ...
            optics.Time(newEndRange), optics.led3(newEndRange) );
        grid;
        
        % ask user if this is good enough to select an end or do more zooming
        endGoodTxt = 'Is this zoom level good enough? (y/n): ';
        endGood = lower(input(endGoodTxt,'s'));        
        
        switch(endGood)
            case 'y'
                endRegionDefined = true;
            otherwise
                endRegionDefined = false;
        end
        
    end
    
    % once region is good, click for end
    
    fprintf('Click once to select the trial end point.\n');
    [xEnd, ~, ~] = ginput(1);
    xAxis = gca;
    partEnd = num2ruler(xEnd, xAxis.XAxis);
    
    opticsEnd = retime(optics, partEnd, 'nearest');
    kinematicsEnd = retime(kinematics, partEnd, 'nearest');
    pressureEnd = retime(pressure, partEnd, 'nearest');
    magEnd = retime(mag, partEnd, 'nearest');
    powerEnd = retime(power, partEnd, 'nearest');
    
    partitionRange = timerange(opticsStart.Time, opticsEnd.Time);
    
    oRange = timerange(opticsStart.Time,opticsEnd.Time);
    kRange = timerange(kinematicsStart.Time, kinematicsEnd.Time);
    pRange = timerange(pressureStart.Time, pressureEnd.Time);
    mRange = timerange(magStart.Time, magEnd.Time);
    wRange = timerange(powerStart.Time, powerEnd.Time);
    
    fprintf('Generating a plot of the proposed partition.\n');
    
    figure(figPart);
    
    pOk1 = subplot(311);
    plot(optics.Time(partitionRange), optics.led2(partitionRange), ...
        optics.Time(partitionRange), optics.led3(partitionRange) );
    xlim([opticsStart.Time opticsEnd.Time]);
    xlabel('Time, local');
    ylabel('Raw intensities');
    grid;
    legend('1050 nm', '1200 nm');
    
    pOk2 = subplot(312);
    plot(kinematics.Time(partitionRange), kinematics.ax(partitionRange), ...
        kinematics.Time(partitionRange), kinematics.ay(partitionRange), ...
        kinematics.Time(partitionRange), kinematics.az(partitionRange) );
    xlim([kinematicsStart.Time kinematicsEnd.Time]);
    xlabel('Time, seconds');
    ylabel('Ax · Ay · Az');
    grid;
    legend('ax','ay','az');
    
    pOk3 = subplot(313);
    plot(pressure.Time(partitionRange), pressure.depth(partitionRange), ...
        'Color', blue);
    set(gca, 'YDir','reverse');
    xlim([pressureStart.Time, pressureEnd.Time]);
    xlabel('Time, seconds');
    ylabel('Depth, meters');
    grid;
    
    linkaxes([pOk1 pOk2 pOk3],'x');
    
    allGoodTxt = 'Are you completely satisifed with this partitioning (y/n): ';
    allGoodStr = lower(input(allGoodTxt,'s'));
    switch(allGoodStr)
        case 'y'
            doPartitioning = false;
        otherwise
            fprintf('Feeling skittish eh? OK, starting over!\n');
            doPartitioning = true;
    end
    
end

%% Ready to create a new timetable with only the partitioned data?

partTimeTableTxt = 'Ready to create a timetable using only partition data (y/n)? ';
partCreateStr = lower(input(partTimeTableTxt,'s'));
switch(partCreateStr)
    case 'y'
        
        oRange = timerange(opticsStart.Time, opticsEnd.Time);
        kRange = timerange(kinematicsStart.Time, kinematicsEnd.Time);
        pRange = timerange(pressureStart.Time, pressureEnd.Time);
        mRange = timerange(magStart.Time, magEnd.Time);
        wRange = timerange(powerStart.Time, powerEnd.Time);
        
        oResize = optics.Time(oRange);
        kResize = kinematics.Time(kRange);
        pResize = pressure.Time(pRange);
        mResize = mag.Time(mRange);
        wResize = power.Time(wRange);
        
        OPTICS = retime(optics, oResize, 'Timestep', ...
            optics.Properties.TimeStep );
        OPTICS.Properties.TimeStep = optics.Properties.TimeStep;
        OPTICS.Properties.SampleRate = optics.Properties.SampleRate;
        OPTICS.tagOnTime_s = OPTICS.time_s;
        opticsTimeOffset = OPTICS.time_s(1);
        OPTICS.time_s = OPTICS.time_s - opticsTimeOffset;
        
        KINEMATICS = retime(kinematics, kResize);
        KINEMATICS.Properties.TimeStep = kinematics.Properties.TimeStep;
        KINEMATICS.Properties.SampleRate = kinematics.Properties.SampleRate;
        KINEMATICS.tagOnTime_s = KINEMATICS.time_s;
        kinematicsTimeOffset = KINEMATICS.time_s(1);
        KINEMATICS.time_s = KINEMATICS.time_s - kinematicsTimeOffset;
        
        PRESSURE = retime(pressure, pResize);
        PRESSURE.Properties.TimeStep = pressure.Properties.TimeStep;
        PRESSURE.Properties.SampleRate = pressure.Properties.SampleRate;
        PRESSURE.tagOnTime_s = PRESSURE.time_s;
        pressureTimeOffset = PRESSURE.time_s(1);
        PRESSURE.time_s = PRESSURE.time_s - pressureTimeOffset;
        
        MAG = retime(mag, mResize);
        MAG.Properties.TimeStep = mag.Properties.TimeStep;
        MAG.Properties.SampleRate = mag.Properties.SampleRate;
        MAG.tagOnTime_s = MAG.time_s;
        magTimeOffset = MAG.time_s(1);
        MAG.time_s = MAG.time_s - magTimeOffset;
        
        POWER = retime(power, wResize);
        POWER.Properties.TimeStep = power.Properties.TimeStep;
        POWER.Properties.SampleRate = power.Properties.SampleRate;
        POWER.tagOnTime_s = POWER.time_s;
        powerTimeOffset = POWER.time_s(1);
        POWER.time_s = POWER.time_s - powerTimeOffset;
        
    otherwise
        
        fprintf('Leaving entire timetable data in place.\n');
        fprintf('This is not recommended and may impair post-processing.\n');
        return;
        
end

close(figPart);

%% Plot and align / adjust CUE entries

maxCueIndex = height(CUE);

originalFirstCueTime = CUE.Time(1);

figTrial = figure;

pAlign1 = subplot(211);
p1 = plot(KINEMATICS.Time, KINEMATICS.odba, 'Color', blue);
xlim([KINEMATICS.Time(1) KINEMATICS.Time(end)]);
xlabel('Time, local');
ylabel('m/s^2');
hold on;

for i = 1:maxCueIndex
    switch(string(CUE.type(i)))
        case '1'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
        case '2'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
        case '3'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
        case '4'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
        case '*'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', goldenrod, 'Marker', '*');
            xline(CUE.Time(i), 'Color', goldenrod);
    end
end
hold off;
xlabel('Time, local');
ylabel('ODBA');
grid;

pAlign2 = subplot(212);
p2 = plot(PRESSURE.Time, PRESSURE.depth, 'Color', blue);
set(gca,'YDir','Reverse');
hold on;
for i = 1:maxCueIndex
    switch(string(CUE.type(i)))
        case '1'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
        case '2'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
        case '3'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
        case '4'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
        case '*'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', goldenrod, 'Marker', '*');
            xline(CUE.Time(i), 'Color', goldenrod);
    end
end
hold off;
xlim([PRESSURE.Time(1), PRESSURE.Time(end)]);
xlabel('Time, local');
ylabel('Depth, meters');
grid;

linkaxes([pAlign1 pAlign2],'x');

durationDifference = OPTICS.Time(1) - datetime(CUE.Time(1), ...
    'Format', 'dd-MMM-y HH:mm:ss' );
secondsDifference = seconds(durationDifference);
fprintf('OPTICS.Time(1) vs CUE.Time(1) difference: %d seconds\n', ...
    secondsDifference);

coarseAdjustChoice = lower(input('Perform coarse adjustment (y/n) [y]): ','s'));
if (isempty(coarseAdjustChoice))
    coarseAdjustChoice = 'y';
end
switch(coarseAdjustChoice)
    case 'y'
        for i = 1:maxCueIndex
            CUE.Time(i) = CUE.Time(i) + durationDifference;
        end
        fprintf('Completed adjustments to TRIAL.CUE.time(*).\n');
    otherwise
        fprintf('Making no adjustments to TRIAL.CUE.time(*).\n');
end

figure(figTrial);
clf(figTrial);
pAlign1 = subplot(211);
p1 = plot(KINEMATICS.Time, KINEMATICS.odba, 'Color', blue);
xlim([KINEMATICS.Time(1) KINEMATICS.Time(end)]);
hold on;
for i = 1:maxCueIndex
    switch(string(CUE.type(i)))
        case '1'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
        case '2'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
        case '3'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
        case '4'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
        case '*'
            plot(CUE.Time(i), max(p1.YData), ...
                'Color', goldenrod, 'Marker', '*');
            xline(CUE.Time(i), 'Color', goldenrod);
    end
end
hold off;
xlabel('Time, local');
ylabel('ODBA');
grid;

pAlign2 = subplot(212);
p2 = plot(PRESSURE.Time, PRESSURE.depth, 'Color', blue);
set(gca,'YDir','Reverse');
hold on;
for i = 1:maxCueIndex
    switch(string(CUE.type(i)))
        case '1'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
        case '2'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
        case '3'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
        case '4'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
        case '*'
            plot(CUE.Time(i), max(p2.YData), ...
                'Color', goldenrod, 'Marker', '*');
            xline(CUE.Time(i), 'Color', goldenrod);
    end
end
hold off;
xlim([PRESSURE.Time(1), PRESSURE.Time(end)]);
xlabel('Time, local');
ylabel('Depth, meters');
grid;

linkaxes([pAlign1 pAlign2],'x');

cueAlignComplete = false;
updatePlot = false;

while (~cueAlignComplete)
    
    fprintf('[b]ack 5s · [f]orward 5s · [space] +1s · [m]ove +/- seconds · [g]ood · [q]uit\n');
    
    [~,~,button] = ginput(1);
    
    switch(char(button))
        case 'f'
            for i = 1:maxCueIndex
            	CUE.Time(i) = CUE.Time(i) + duration([0 0 5]);
            end
            cueAlignComplete = false
            updatePlot = true;
            
        case 'b'
            for i = 1:maxCueIndex
            	CUE.Time(i) = CUE.Time(i) - duration([0 0 5]);
            end            
            cueAlignComplete = false
            updatePlot = true;
        
        case ' '
            for i = 1:maxCueIndex
            	CUE.Time(i) = CUE.Time(i) + duration([0 0 1]);
            end            
            cueAlignComplete = false
            updatePlot = true;
            
        case 'm'
            secondsUpdateText = 'Enter +/- seconds adjustment: ';
            secondsUpdate = str2double(input(secondsUpdateText,'s'));
            if (isnumeric(secondsUpdate))
                fprintf('Updating by %d seconds...\n', secondsUpdate);
                newDurationOffset = duration([ 0 0 secondsUpdate]);
                for i = 1:maxCueIndex
                    CUE.Time(i) = CUE.Time(i) + newDurationOffset;
                end            
                cueAlignComplete = false;
                updatePlot = true;
            else
                fprintf('That was an invalid number of seconds. Try again.\n');
            end
            
        case 'g'
            
            alignDurationDiff = originalFirstCueTime - CUE.Time(1);
            fprintf('Alignment difference: %d seconds.\n', ...
                seconds(alignDurationDiff) );
            alignSaveText = 'You said aligment looks good. Want to save? (y/n) [n]: ';
            alignSaveStr = lower(input(alignSaveText, 's'));
            switch(alignSaveStr)
                case 'y'
                    TRIAL.tagTimelogTimeDifference = alignDurationDiff;
                    TRIAL.CUES.tagTimeOffset = alignDurationDiff;
                    TRIAL.CUES.timeSyncComplete = 'yes';
                    TRIAL.CUES.timeSyncBy = 'Dave Haas';
                    save(fullMetadataFileName, 'TRIAL');
                otherwise
                    fprintf('Exiting without saving. Re-run to save.\n');
            end
            
            cueAlignComplete = true;
            
        case 'q'
            fprintf('Quitting cue alignment tool.\n');
            cueAlignComplete = true;
            updatePlot = false;
            
        otherwise
            cueAlignComplete = false;
            updatePlot = false;
            
    end
    
    if (updatePlot)

        if (isempty(figTrial.findobj))
            figTrial = figure;
        else
            
            clf(figTrial);
            figure(figTrial);
            
        end
        
        pAlign1 = subplot(211);
        p1 = plot(KINEMATICS.Time, KINEMATICS.odba, 'Color', blue);
        xlim([KINEMATICS.Time(1) KINEMATICS.Time(end)]);
        hold on;
        for i = 1:maxCueIndex
            switch(string(CUE.type(i)))
                case '1'
                    plot(CUE.Time(i), max(p1.YData), ...
                        'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
                case '2'
                    plot(CUE.Time(i), max(p1.YData), ...
                        'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
                case '3'
                    plot(CUE.Time(i), max(p1.YData), ...
                        'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
                case '4'
                    plot(CUE.Time(i), max(p1.YData), ...
                        'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
                case '*'
                    plot(CUE.Time(i), max(p1.YData), ...
                        'Color', goldenrod, 'Marker', '*');
                    xline(CUE.Time(i), 'Color', goldenrod);
            end
        end         % end maxCue iteration
        hold off;   % make sure to do no more plot updating
        xlabel('Time, local');
        ylabel('ODBA');
        grid;
        
        pAlign2 = subplot(212);
        p2 = plot(PRESSURE.Time, PRESSURE.depth, 'Color', blue);
        set(gca,'YDir','Reverse');
        hold on;
        for i = 1:maxCueIndex
            switch(string(CUE.type(i)))
                case '1'
                    plot(CUE.Time(i), max(p2.YData), ...
                        'Color', maroon, 'Marker', 'd', 'MarkerFaceColor', maroon);            
                case '2'
                    plot(CUE.Time(i), max(p2.YData), ...
                        'Color', green, 'Marker', '^', 'MarkerFaceColor', green);
                case '3'
                    plot(CUE.Time(i), max(p2.YData), ...
                        'Color', red, 'Marker', 'v', 'MarkerFaceColor', red);
                case '4'
                    plot(CUE.Time(i), max(p2.YData), ...
                        'Color', blue, 'Marker', '^', 'MarkerFaceColor', blue);
                case '*'
                    plot(CUE.Time(i), max(p2.YData), ...
                        'Color', goldenrod, 'Marker', '*');
                    xline(CUE.Time(i), 'Color', goldenrod);
            end
        end
        hold off;
        xlim([PRESSURE.Time(1), PRESSURE.Time(end)]);
        xlabel('Time, local');
        ylabel('Depth, meters');
        grid;

        linkaxes([pAlign1 pAlign2],'x');

    end             % end updatePlot
end                 % end cue alignment


%% Confirm that these partition-adjusted time series are good

figAlign = figure;

s1 = subplot(411);
p1 = plot(OPTICS.Time, OPTICS.led1, 'Color', black);
hold on;
p2 = plot(OPTICS.Time, OPTICS.led2, 'Color', blue);
p3 = plot(OPTICS.Time, OPTICS.led3, 'Color', red);
p4 = plot(OPTICS.Time, OPTICS.led4, 'Color', goldenrod);
yPos = max([ max(p1.YData) max(p2.YData) max(p3.YData) max(p4.YData) ]);
numCuePlots = ftPlotCues(CUE.Time(:), CUE.type(:), yPos);
hold off;
xlabel('Time, seconds');
ylabel('Reflectance (A.U.)');
xlim([OPTICS.Time(1) OPTICS.Time(end)]);
grid;
legend('amb1','1050 nm','1200 nm','amb2');

s2 = subplot(412);
p5 = plot(KINEMATICS.Time, KINEMATICS.ax, 'Color', blue);
hold on;
p6 = plot(KINEMATICS.Time, KINEMATICS.ay, 'Color', red);
p7 = plot(KINEMATICS.Time, KINEMATICS.az, 'Color', goldenrod);
yPos = max([ max(p5.YData) max(p6.YData) max(p7.YData) ]);
numCuePlots = ftPlotCues(CUE.Time(:), CUE.type(:), yPos);
hold off;
xlabel('Time, seconds');
ylabel('m/s^2');
xlim([KINEMATICS.Time(1) KINEMATICS.Time(end)]);
grid;

s3 = subplot(413);
p8 = plot(KINEMATICS.Time, KINEMATICS.gx, 'Color', blue);
hold on;
p9 = plot(KINEMATICS.Time, KINEMATICS.gy, 'Color', red);
p10 = plot(KINEMATICS.Time, KINEMATICS.gz, 'Color', goldenrod);
yPos = max([ max(p8.YData) max(p9.YData) max(p10.YData) ]);
numCuePlots = ftPlotCues(CUE.Time(:), CUE.type(:), yPos);
hold off;
xlabel('Time, seconds');
ylabel('°/s');
xlim([KINEMATICS.Time(1) KINEMATICS.Time(end)]);
grid;

s4 = subplot(414);
p11 = plot(PRESSURE.Time, PRESSURE.depth, 'Color', blue);
hold on;
yPos = max(p11.YData);
numCuePlots = ftPlotCues(CUE.Time(:), CUE.type(:), yPos);
hold off;
xlabel('Time, seconds');
ylabel('Depth, meters');
set(gca, 'YDir','reverse');
xlim([PRESSURE.Time(1) PRESSURE.Time(end)]);
grid;

linkaxes([s1 s2 s3 s4],'x');

%% Does all that look good

confirmTxt = 'Does everything in this plot look good? (y/n): ';
confirmStr = lower(input(confirmTxt,'s'));
switch(confirmStr)
    case 'y'
        okayToProceed = true;
        
        close(figTrial);
        close(figAlign);
        
    otherwise
        okayToProceed = false;
end

%% Safe to continue? Is post-processing all done?

proceedTxt = 'Continue with decimation? (y/n): ';
proceedStr = lower(input(proceedTxt,'s'));
switch(proceedStr)
    case 'y'
        fprintf('Proceeding with decimation...\n');
        safeToProceed = true;
    otherwise
        fprintf('You said no, so stopping execution here. Rerun when ready.\n');
        return;
end


%% Decimate optical (250 Hz) + accel, gyro, depth & temp (100 Hz) to 25 Hz

fprintf('Decimating optical, movement, depth & temp data to 25Hz...\n');

oT = downsample(OPTICS.Time, 10);
oT_s = downsample(OPTICS.time_s, 10);
led1_25Hz = decimate(OPTICS.led1, 10);         % decimate 250 Hz by a factor of 10
led2_25Hz = decimate(OPTICS.led2, 10);
led3_25Hz = decimate(OPTICS.led3, 10);
led4_25Hz = decimate(OPTICS.led4, 10);

kT = downsample(KINEMATICS.Time, 4);
kT_s = downsample(KINEMATICS.time_s, 4);
ax_25Hz = decimate(KINEMATICS.ax, 4);              % decimate 100 Hz by a factor of 4
ay_25Hz = decimate(KINEMATICS.ay, 4);
az_25Hz = decimate(KINEMATICS.az, 4);

gx_25Hz = decimate(KINEMATICS.gx, 4);
gy_25Hz = decimate(KINEMATICS.gy, 4);
gz_25Hz = decimate(KINEMATICS.gz, 4);

pitch_25Hz   = decimate(KINEMATICS.pitch, 4);
roll_25Hz    = decimate(KINEMATICS.roll, 4);
heading_25Hz = decimate(KINEMATICS.heading, 4);

odba_25Hz = decimate(KINEMATICS.odba, 4);
odav_25Hz = decimate(KINEMATICS.odav, 4);

depth_25Hz          = decimate(PRESSURE.depth, 4);
temperature_25Hz    = decimate(PRESSURE.temperature, 4);

% confirm lengths of optics vs. kinematics

if (length(odba_25Hz) == length(led1_25Hz) )
    
    fprintf('Decimated optics and kinematics have matching lengths.\n');

else
    
    fprintf('Decimated optics and kinematics have differing lengths.\n');
    dOpticsLength = length(led1_25Hz);
    dKinematicsLength = length(odba_25Hz);
    fprintf('Optics length: %d | Kinematics length: %d\n', ...
        dOpticsLength, dKinematicsLength);
    
    figDec = figure;
    plot(oT, normalize(led2_25Hz), 'Color', blue);
    hold on;
    plot(oT, normalize(led3_25Hz), 'Color', red);
    plot(kT, normalize(odba_25Hz), 'Color', goldenrod);
    grid;
    legend('1050 nm','1200 nm', 'ODBA');
    
    fprintf('Exam this figure closely before approving truncation.\n');
    
    if (dOpticsLength > dKinematicsLength)
        
        dOffset = dOpticsLength - dKinematicsLength;
        fprintf('Proposal: truncate the last %d optical sample(s)\n', ...
            dOffset);
        truncateStr = lower(input('Okay to truncate (y/n): ','s'));
        switch(truncateStr)
            case 'y'
            	oT = oT(1:end-dOffset);
                oT_s = oT_s(1:end-dOffset);
                led1_25Hz = led1_25Hz(1:end-dOffset);
                led2_25Hz = led2_25Hz(1:end-dOffset);
                led3_25Hz = led3_25Hz(1:end-dOffset);
                led4_25Hz = led4_25Hz(1:end-dOffset);
            otherwise
                fprintf('Leaving optics with that extra %d sample(s).\n', ...
                    dOffset);
        end
        
        
    else
        
        dOffset = dKinematicsLength - dOpticsLength;

        fprintf('Proposal: truncate the last %d kinematic sample(s)\n', ...
            dOffset);
       truncateStr = lower(input('Okay to truncate (y/n): ','s'));
        switch(truncateStr)
            case 'y'
                kT = kT(1:end-dOffset);
                kT_s = kT_s(1:end-dOffset);
                ax_25Hz = ax_25Hz(1:end-dOffset);
                ay_25Hz = ay_25Hz(1:end-dOffset);
                az_25Hz = az_25Hz(1:end-dOffset);
                gx_25Hz = gx_25Hz(1:end-dOffset);
                gy_25Hz = gy_25Hz(1:end-dOffset);
                gz_25Hz = gz_25Hz(1:end-dOffset);
                pitch_25Hz = pitch_25Hz(1:end-dOffset);
                roll_25Hz = roll_25Hz(1:end-dOffset);
                heading_25Hz = heading_25Hz(1:end-dOffset);
                odba_25Hz = odba_25Hz(1:end-dOffset);
                odav_25Hz = odav_25Hz(1:end-dOffset);
                depth_25Hz = depth_25Hz(1:end-dOffset);
                temperature_25Hz = temperature_25Hz(1:end-dOffset);
            otherwise
                fprintf('Leaving optics with that extra %d sample(s).\n', ...
                    dOffset);
        end
        
    end         % end differing optics length from kinematics length
    
    if (exist('figDec','var'))
        close(figDec);
    end
    
end             % end decimated time series difference tests



%% Build timetable for 25 Hz PRH file

O = timetable(oT, oT_s, led1_25Hz, led2_25Hz, led3_25Hz, led4_25Hz, ...
    'VariableNames', {'time_s','led1','led2','led3','led4'} );

K = timetable(kT, kT_s, ax_25Hz, ay_25Hz, az_25Hz, gx_25Hz, ...
    gy_25Hz, gz_25Hz, pitch_25Hz, roll_25Hz, heading_25Hz, ...
    odba_25Hz, odav_25Hz, 'VariableNames', ...
    {'time_s','ax','ay','az','gx','gy','gz','pitch', ...
    'roll', 'heading', 'odba', 'odav'} );

P = timetable(kT, kT_s, depth_25Hz, temperature_25Hz, ...
    'VariableNames', {'time_s','depth','temperature' } );


%% Make sure that 'tag' and TRIAL.tag are the same, 
%   and have the user fix if not

if (strcmp(tag, CUE.Properties.CustomProperties.tag))     % tag and TRIAL.tag match
    fprintf('CUE.Props...tag and tag variable match. This is good news!\n');
else                            % tag and TRIAL.tag do not match
    fprintf('CUE.Props...tag and tag variable do not match. Resolve now...\n');
    fprintf('\tCUE.Props...tag = %s\n', CUE.Properties.CustomProperties.tag);
    fprintf('\ttag = %s\n', tag);
    tagIdResolveText = 'Do you want to set `tag` equal to CUE.Props...tag? (y/n) [y]: ';
    tagIdResolveStr = lower(input(tagIdResolveText,'s'));
    if (isempty(tagIdResolveStr))
        tagIdResolveStr = 'y';
    end
    switch (tagIdResolveStr)
        case 'y'
            tag = CUE.Properties.CustomProperties.tag;
            fprintf('Renamed `tag`: %s\n', tag);
            rawFileName = sprintf('%sraw.mat', tag);
            fprintf('Renamed RAW file: %s\n', rawFileName);
            prhFileName = sprintf('%sprh.mat', tag);
            fprintf('Renamed PRH file: %s\n', prhFileName);
        otherwise
            fprintf('Taking no action and going with aggregated RAW & PRH files.\n');
    end 
end


%% save all RAW data structs as a somewhat Dtag-compatible raw file

global TAG_PATHS;

rawFile = sprintf('%s/%s', TAG_PATHS.RAW, rawFileName);

fprintf('Creating RAW file: %s\n', rawFile);

if (exist(rawFile, 'file'))
    
    fprintf('RAW file exists... ');
    
    prompt = 'over-write and re-create? y/n [n]: ';
    str = input(prompt,'s');
    if isempty(str)
        str = 'n';
    end
    
    if (strcmp(str, 'y'))
       fprintf('\nOver-writing and re-creating RAW file...\n');
       save(rawFile, 'OPTICS', 'KINEMATICS', 'PRESSURE', ...
            'MAG', 'POWER', 'CUE', 'TAG', 'TRIAL');
    end    
    
else
    
    fprintf('Raw file does not exist... creating...\n');
    save(rawFile, 'OPTICS', 'KINEMATICS', 'PRESSURE', ...
        'MAG', 'POWER', 'CUE', 'TAG', 'TRIAL');
    if (exist(rawFile, 'file'))
        fprintf('Looks like that file was created!\n');
    else
        fprintf('There was some problem saving that raw file. Halting.\n');
    end
    
end


%% save decimated and aligned data to the PRH file

prhFile = sprintf('%s/%s', TAG_PATHS.PRH, prhFileName);

fprintf('Creating PRH file: %s\n', prhFile);

if (exist(prhFile, 'file'))
    
    fprintf('PRH file exists... ');
    
    prompt = 'over-write and re-create? y/n [n]: ';
    str = input(prompt,'s');
    if isempty(str)
        str = 'n';
    end
    
    if (strcmp(str, 'y'))
       fprintf('\nOver-writing and re-creating PRH file...\n');
       save(prhFile, 'O', 'K', 'P', 'CUE', 'TAG', 'TRIAL');
    end
    
else
    fprintf('PRH file does not exist... creating...\n');
    save(prhFile, 'O', 'K', 'P', 'CUE', 'TAG', 'TRIAL');
    if (exist(prhFile, 'file'))
        fprintf('Looks like that file was created!\n');
    else
        fprintf('There was some problem saving that raw file. Halting.\n');
    end
end

%% Confirm RAW and PRH files are where they should be...

if (exist(rawFile, 'file'))
    fprintf('Good news: RAW file is where it should be!\n');
else
    fprintf('Bad news: RAW file is missing from PRH folder. Investigate.\n');
end

if (exist(prhFile, 'file'))
    fprintf('Good news: PRH file is where it should be!\n');
else
    fprintf('Bad news: PRH file is missing from PRH folder. Investigate.\n');
end

%% Okay! RAW and PRH files should have been created. Now what?
%   
%   1. recommend separation of all of the above steps as a separate script,
%       e.g.: 'FaunaData_PostProcessing.m'
%   
%   2. recommend writing a separate tool to partition multi-trial data
%       sets, call it 'FaunaData_Partioner.m'
%
%   3. recommend separation of:
%           a) all of the below figure plotting
%           b) 'FaunaTagDataSheetInput.m' 
%           c) 'FaunaTag_OpticalGaussianFilter.m' 
%      into 'FaunaData_Analysis.m'

fprintf('Basic RAW and PRH files are created.\n');


%% Done!

fprintf('Post-processing complete! Trial is: %s\n', tag);

closeFigsStr = lower(input('Close all open figures? (y/n): ','s'));
switch(closeFigsStr)
    case 'y'
        fprintf('Closing open figures...\n');
        figHandles = get(groot, 'Children');
        if (~isempty(figHandles))
            close(figHandles);
        end
    otherwise
        fprintf('Leaving figures in place...\n');
end


%% %% Do a bandpass filter of 250 Hz for O2 sat

% %   These are filter options for relative O2 tissue saturation
% 
% filterStr = 'High-pass (h) | Low-pass (l) | Band-pass (b) [b]: ';
% validFilter = false;
% 
% while (~validFilter)
%     
%     o2FilterOptionStr = lower(input(filterStr,'s'));
% 
%     if (isempty(o2FilterOptionStr))
%         o2FilterOptionStr = 'b';
%     end
%     
%     switch(o2FilterOptionStr)
%         
%         case 'l'
%             validFilter = false;
%             fprintf('For now, there is no low-pass filter option.\n');
% %             bwFiltOrder     = 3;        % FieldTrip suggested default
% %             passbandFreqHz  = 0.8;     % FieldTrip suggested default
% %             nyquistFs       = 250;       % should probably experiment with range
% % 
% %             fprintf('Filter order: %d\n', bwFiltOrder);
% %             fprintf('Passband frequency: %d Hz\n', passbandFreqHz);
% %             fprintf('Nyquist frequency: %d\n', nyquistFs);
% % 
% % 
% %             % filter coefficients for low-pass
% %             [Alow, Blow] = butter(bwFiltOrder, ( passbandFreqHz / (nyquistFs / 2) ) );
% % 
% %             ODLed1 = filter(Blow, Alow, odLed1);    
%         
%         case 'h'
%             validFilter = true;
%             bwFiltOrder     = 3;        % FieldTrip suggested default
%             passbandFreqHz  = 0.01;     % FieldTrip suggested default
%             nyquistFs       = 125;       % should probably experiment with range
% 
%             fprintf('Filter order: %d\n', bwFiltOrder);
%             fprintf('Passband frequency: %d Hz\n', passbandFreqHz);
%             fprintf('Nyquist frequency: %d\n', nyquistFs);
% 
%             % filter coefficients for high-pass
%             %[Ao2, Bo2, Co2, Do2] = butter(bwFiltOrder/2, ( passbandFreqHz / (nyquistFs/2) ) );
%             [Ao2, Bo2, Co2, Do2] = butter(bwFiltOrder, ( passbandFreqHz / (nyquistFs) ) );
% 
%             % design the high-pass filter
%             o2BwFilt = designfilt('highpassiir','FilterOrder',bwFiltOrder, ...
%                 'PassbandFrequency',passbandFreqHz, ... 
%                 'PassbandRipple', 0.2, ...
%                 'SampleRate', nyquistFs);
%             
%         case 'b'
%             
%             validFilter = true;
%             bwFiltOrder = 4;        % 20th order butterworth filter
%             lowCut      = 0.01;       % 0.01 Hz   = fluctuations over 10 seconds
%             highCut     = 0.1;        % 0.1 Hz    = fluctuations over 100 seconds
%             nyquistFs   = 25;        
% 
%             fprintf('Applying a band-pass filter with the following properties:\n');
%             fprintf('Filter order: %d\n', bwFiltOrder);
%             fprintf('Low cut frequency: %d Hz\n', lowCut );
%             fprintf('High cut frequency: %d Hz\n', highCut );
%             fprintf('Nyquist frequency: %d\n', nyquistFs);
% 
%             % band-pass
%             [Ao2, Bo2, Co2, Do2] = butter(bwFiltOrder/2, [lowCut highCut] / (nyquistFs/2) );
% 
%             % design the band-pass filter
%             o2BwFilt = designfilt('bandpassiir','FilterOrder',bwFiltOrder, ...
%                 'HalfPowerFrequency1',lowCut,'HalfPowerFrequency2',highCut, ...
%                 'SampleRate', nyquistFs);   
%             
%         otherwise
%             validFilter = false;
%             
%     end
% 
% end
% 
% % Convert the state-space representation to second-order sections. 
% % Visualize the frequency responses using fvtool.
% 
% sos = ss2sos(Ao2,Bo2,Co2,Do2);
% fvt = fvtool(sos, o2BwFilt, 'Fs', nyquistFs);
% legend(fvt,'butter','designfilt');
% 
% approveFilterStr = lower(input('Is this filter good to go? (y/n) [n]: ','s'));
% 
% switch(approveFilterStr)
% 
%     case 'y'
%         
%         % filter optical data, using d' to row-major output
% 
%         fprintf('Using this filter to for TSI / O2 optical data...\n');
%         
%         o2filtLed1 = filtfilt(o2BwFilt', led1);
%         o2filtLed2 = filtfilt(o2BwFilt', led2);
%         o2filtLed3 = filtfilt(o2BwFilt', led3);
%         o2filtLed4 = filtfilt(o2BwFilt', led4);
%         
%         o2FiltLed1 = rescale(o2filtLed1, 0, max(o2filtLed1));
%         o2FiltLed2 = rescale(o2filtLed2, 0, max(o2filtLed2));
%         o2FiltLed3 = rescale(o2filtLed3, 0, max(o2filtLed3));
%         o2FiltLed4 = rescale(o2filtLed4, 0, max(o2filtLed4));
%         
%         odLed1 = log( max(o2FiltLed1) ./ o2FiltLed1 );
%         odLed2 = log( max(o2FiltLed2) ./ o2FiltLed2 );
%         odLed3 = log( max(o2FiltLed3) ./ o2FiltLed3 );
%         odLed4 = log( max(o2FiltLed4) ./ o2FiltLed4 );
% 
%         figure;
%         plot(opticsTime_s, odLed1, 'k-');
%         hold on;
%         plot(opticsTime_s, odLed2, 'b-');
%         plot(opticsTime_s, odLed3, 'r-');
%         plot(opticsTime_s, odLed4, 'g-');
%         hold off;
%         grid;
%         xlabel('Time, seconds');
%         ylabel('Optical density');
%         titleStr = ... 
%             sprintf('OD (0.01 Hz HPF w/ rescale) - RAW %s', TRIAL.tag);
%         title(titleStr);
%         legend('Amb1','1050 nm','1200 nm','amb2');
%         
%         odLed1_25Hz = downsample(odLed1, 10);
%         odLed2_25Hz = downsample(odLed2, 10);
%         odLed3_25Hz = downsample(odLed3, 10);
%         odLed4_25Hz = downsample(odLed4, 10);
%         
%         figure;
%         plot(time_s, odLed1_25Hz, 'k-');
%         hold on;
%         plot(time_s, odLed2_25Hz, 'b-');
%         plot(time_s, odLed3_25Hz, 'r-');
%         plot(time_s, odLed4_25Hz, 'g-');
%         hold off;
%         grid;
%         xlabel('Time, seconds');
%         ylabel('Optical density');
%         titleStr = ... 
%             sprintf('OD (0.01 Hz HPF w/ rescale) - PRH %s', TRIAL.tag);
%         title(titleStr);
%         legend('Amb1','1050 nm','1200 nm','amb2');
% 
%         validFilter = true;
% 
%     otherwise
%         
%         fprintf('Re-run this optical filtering for O2.\n');
%         return;
% 
% end
% 
% 
