function z = sem(x)

    z = std(x) / (sqrt(length(x)));